<?php

require_once(__DIR__ . '/cmb2/init.php');

add_action( 'cmb2_admin_init', 'themefushion_addons_register_metabox' );

function themefushion_addons_register_metabox() {

	$prefix = 'themefushion_addons_';

	global $mobimab_themefushion;

	$main_color = (isset($GLOBALS['mobimab_themefushion']['main-color']) && $GLOBALS['mobimab_themefushion']['main-color']) ? $GLOBALS['mobimab_themefushion']['main-color'] : '#ffb700';

	/*  Footer
	/*-------------------*/

		$cmb_footer_layout = new_cmb2_box( array(
			'id'            => $prefix.'footer_options_metabox',
			'title'         => esc_html__( 'Footer options', 'themefushion-addons' ),
			'object_types'  => array( 'footer', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_footer_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_footer_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

		$cmb_footer_layout->add_field( array(
			'name'             => esc_html__( 'Sticky?', 'themefushion-addons' ),
			'id'               => $prefix . 'sticky',
			'type'             => 'checkbox',
		) );

		$cmb_footer_layout->add_field( array(
			'name'        => esc_html__( 'Custom form styling', 'themefushion-addons' ),
			'description' => esc_html__( 'If you use form elements in the footer you can configure form styles here', 'themefushion-addons' ),
			'id'          => $prefix . 'custom_form_styling',
			'type'        => 'checkbox',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Field text color', 'themefushion-addons' ),
			'id'      => $prefix . 'field_color',
			'type'    => 'colorpicker',
			'default' => '#616161',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Field text color focus', 'themefushion-addons' ),
			'id'      => $prefix . 'field_color_focus',
			'type'    => 'colorpicker',
			'default' => '#616161',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Field background color', 'themefushion-addons' ),
			'id'      => $prefix . 'field_back_color',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Field background color focus', 'themefushion-addons' ),
			'id'      => $prefix . 'field_back_color_focus',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Field border color', 'themefushion-addons' ),
			'id'      => $prefix . 'field_border_color',
			'type'    => 'colorpicker',
			'default' => '#e0e0e0',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Field border color focus', 'themefushion-addons' ),
			'id'      => $prefix . 'field_border_color_focus',
			'type'    => 'colorpicker',
			'default' => '#e0e0e0',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Button text color', 'themefushion-addons' ),
			'id'      => $prefix . 'button_color',
			'type'    => 'colorpicker',
			'default' => '#000000',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Button text color hover', 'themefushion-addons' ),
			'id'      => $prefix . 'button_color_hover',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Button background color', 'themefushion-addons' ),
			'id'      => $prefix . 'button_back_color',
			'type'    => 'colorpicker',
			'default' => $main_color,
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Button background color hover', 'themefushion-addons' ),
			'id'      => $prefix . 'button_back_color_hover',
			'type'    => 'colorpicker',
			'default' => '#1c1c1e',
			'classes' => 'custom-form-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'        => esc_html__( 'Custom widget styling', 'themefushion-addons' ),
			'description' => esc_html__( 'If you use widgets in the footer you can configure widgets styles here', 'themefushion-addons' ),
			'id'          => $prefix . 'custom_widget_styling',
			'type'        => 'checkbox',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Widget title color', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_title_color',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-widget-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Widget text color', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_color',
			'type'    => 'colorpicker',
			'default' => '#bdbdbd',
			'classes' => 'custom-widget-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Widget link color', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_link_color',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-widget-styling',
		) );

		$cmb_footer_layout->add_field( array(
			'name'    => esc_html__( 'Widget link color hover', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_link_color_hover',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-widget-styling',
		) );

	/*  Header
	/*-------------------*/

		$cmb_header_layout = new_cmb2_box( array(
			'id'            => $prefix.'header_options_metabox',
			'title'         => esc_html__( 'Header options', 'themefushion-addons' ),
			'object_types'  => array( 'header', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_header_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_header_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

		$cmb_header_layout->add_field( array(
			'name'             => esc_html__( 'Header type', 'themefushion-addons' ),
			'id'               => $prefix . 'header_type',
			'type'             => 'select',
			'classes'          => 'select-230',
			'options'          => array(
				'desktop'      => esc_html__( 'Desktop', 'themefushion-addons' ),
				'mobile'       => esc_html__( 'Mobile', 'themefushion-addons' ),
				'sidebar'      => esc_html__( 'Sidebar', 'themefushion-addons' ),
			),
			'default' => 'desktop',
		) );

		$cmb_header_layout->add_field( array(
			'name'             => esc_html__( 'Transparent', 'themefushion-addons' ),
			'id'               => $prefix . 'transparent',
			'type'             => 'checkbox',
			'classes'          => 'sidebar-off',
		) );

		$cmb_header_layout->add_field( array(
			'name'             => esc_html__( 'Sticky', 'themefushion-addons' ),
			'id'               => $prefix . 'sticky',
			'type'             => 'checkbox',
			'classes'          => 'sidebar-off',
		) );

		$cmb_header_layout->add_field( array(
			'name'             => esc_html__( 'Shadow', 'themefushion-addons' ),
			'id'               => $prefix . 'shadow',
			'type'             => 'checkbox',
			'classes'          => 'sidebar-off',
		) );
		$cmb_header_layout->add_field( array(
			'name'             => esc_html__( 'Shadow on sticky', 'themefushion-addons' ),
			'id'               => $prefix . 'shadow_sticky',
			'type'             => 'checkbox',
			'classes'          => 'sidebar-off',
		) );

	/*  Megamenu
	/*-------------------*/

		$cmb_megamenu_layout = new_cmb2_box( array(
			'id'            => $prefix.'megamenu_options_metabox',
			'title'         => esc_html__( 'Megamenu options', 'themefushion-addons' ),
			'object_types'  => array( 'megamenu', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_megamenu_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_megamenu_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

		$cmb_megamenu_layout->add_field( array(
			'name'             => esc_html__( 'Megamenu width', 'themefushion-addons' ),
			'id'               => $prefix . 'megamenu_width',
			'type'             => 'select',
			'classes'          => 'select-230',
			'options'          => array(
				'100'=> '100%',
				'1200' => 'grid width',
				'75' => '75%',
				'60' => '60%',
				'50' => '50%',
				'30' => '30%',
				'25' => '25%',
			),
			'default' => '1200',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'             => esc_html__( 'Megamenu position', 'themefushion-addons' ),
			'id'               => $prefix . 'megamenu_position',
			'type'             => 'select',
			'classes'          => 'select-230 megamenu-toggle',
			'options'          => array(
				'left'=> 'left',
				'right' => 'right',
				'center' => 'center',
			),
			'default' => 'left',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Megamenu horizontal offset in px', 'themefushion-addons' ),
			'description' => esc_html__( 'Enter negative or positive integer value without any string', 'themefushion-addons' ),
			'id'      => $prefix . 'megamenu_offset',
			'classes'          => 'megamenu-toggle',
			'type'    => 'text_small',
			'default' => '',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'        => esc_html__( 'Custom form styling', 'themefushion-addons' ),
			'description' => esc_html__( 'If you use form elements in the megamenu you can configure form styles here', 'themefushion-addons' ),
			'id'          => $prefix . 'custom_form_styling',
			'type'        => 'checkbox',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Field text color', 'themefushion-addons' ),
			'id'      => $prefix . 'field_color',
			'type'    => 'colorpicker',
			'default' => '#616161',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Field text color focus', 'themefushion-addons' ),
			'id'      => $prefix . 'field_color_focus',
			'type'    => 'colorpicker',
			'default' => '#212121',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Field background color', 'themefushion-addons' ),
			'id'      => $prefix . 'field_back_color',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Field background color focus', 'themefushion-addons' ),
			'id'      => $prefix . 'field_back_color_focus',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Field border color', 'themefushion-addons' ),
			'id'      => $prefix . 'field_border_color',
			'type'    => 'colorpicker',
			'default' => '#e0e0e0',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Field border color focus', 'themefushion-addons' ),
			'id'      => $prefix . 'field_border_color_focus',
			'type'    => 'colorpicker',
			'default' => '#e0e0e0',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Button text color', 'themefushion-addons' ),
			'id'      => $prefix . 'button_color',
			'type'    => 'colorpicker',
			'default' => '#000000',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Button text color hover', 'themefushion-addons' ),
			'id'      => $prefix . 'button_color_hover',
			'type'    => 'colorpicker',
			'default' => '#ffffff',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Button background color', 'themefushion-addons' ),
			'id'      => $prefix . 'button_back_color',
			'type'    => 'colorpicker',
			'default' => '#ffb700',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Button background color hover', 'themefushion-addons' ),
			'id'      => $prefix . 'button_back_color_hover',
			'type'    => 'colorpicker',
			'default' => '#1c1c1e',
			'classes' => 'custom-form-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'        => esc_html__( 'Custom widget styling', 'themefushion-addons' ),
			'description' => esc_html__( 'If you use widgets in the megamenu you can configure widgets styles here', 'themefushion-addons' ),
			'id'          => $prefix . 'custom_widget_styling',
			'type'        => 'checkbox',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Widget title color', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_title_color',
			'type'    => 'colorpicker',
			'default' => '#1c1c1e',
			'classes' => 'custom-widget-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Widget text color', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_color',
			'type'    => 'colorpicker',
			'default' => '#616161',
			'classes' => 'custom-widget-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Widget link color', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_link_color',
			'type'    => 'colorpicker',
			'default' => '#ffb700',
			'classes' => 'custom-widget-styling',
		) );

		$cmb_megamenu_layout->add_field( array(
			'name'    => esc_html__( 'Widget link color hover', 'themefushion-addons' ),
			'id'      => $prefix . 'widget_link_color_hover',
			'type'    => 'colorpicker',
			'default' => '#1c1c1e',
			'classes' => 'custom-widget-styling',
		) );

	/*  Banner
	/*-------------------*/

		$cmb_banner_layout = new_cmb2_box( array(
			'id'            => $prefix.'banner_options_metabox',
			'title'         => esc_html__( 'Banner options', 'themefushion-addons' ),
			'object_types'  => array( 'banner', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_banner_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_banner_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

	/*  Title section
	/*-------------------*/

		$cmb_title_section_layout = new_cmb2_box( array(
			'id'            => $prefix.'title_section_options_metabox',
			'title'         => esc_html__( 'Title section', 'themefushion-addons' ),
			'object_types'  => array( 'title_section', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_title_section_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_title_section_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

	/*  Pages
	/*-------------------*/

		$cmb_page_layout = new_cmb2_box( array(
			'id'            => $prefix.'page_options_metabox',
			'title'         => esc_html__( 'Page options', 'themefushion-addons' ),
			'object_types'  => array( 'page', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_page_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_page_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

		$cmb_page_layout->add_field( array(
			'name'             => esc_html__( 'Subtitle', 'themefushion-addons' ),
			'id'               => $prefix . 'subtitle',
			'type'             => 'text_medium',
		) );

		/*  Headers
		/*-------------------*/

			$headers_array = array(
				'none'    => esc_html__( 'None', 'themefushion-addons' ),
				'default' => esc_html__( 'Default', 'themefushion-addons' ),
				'inherit' => esc_html__( 'Inherit', 'themefushion-addons' ),
			);

			$et_header = new WP_Query(array(
	            'post_type'           => 'header',
	            'post_status'         => 'publish',
	            'ignore_sticky_posts' => 0,
	            'orderby'             => 'title',
	            'order'               => 'ASK',
	            'posts_per_page'      => -1,
	        ));

	        if($et_header->have_posts()){
	        	while($et_header->have_posts()) : $et_header->the_post();

	        		$header_id    = get_the_ID();
	        		$header_title = get_the_title($header_id);

	        		$headers_array[$header_id] = $header_title;

	        	endwhile;
	        	wp_reset_postdata();
	        }

	        $cmb_page_layout->add_field( array(
				'name'             => esc_html__( 'Mobile header', 'themefushion-addons' ),
				'id'               => $prefix . 'mobile_header',
				'type'             => 'select',
				'classes'          => 'select-230',
				'options'          => $headers_array,
				'default' => 'inherit',
			) );

			$cmb_page_layout->add_field( array(
				'name'             => esc_html__( 'Desktop header', 'themefushion-addons' ),
				'id'               => $prefix . 'desktop_header',
				'type'             => 'select',
				'classes'          => 'select-230',
				'options'          => $headers_array,
				'default' => 'inherit',
			) );

		/*  Footers
		/*-------------------*/

			$footers_array = array(
				'none'    => esc_html__( 'None', 'themefushion-addons' ),
				'default' => esc_html__( 'Default', 'themefushion-addons' ),
				'inherit' => esc_html__( 'Inherit', 'themefushion-addons' ),
			);

			$et_footer = new WP_Query(array(
	            'post_type'           => 'footer',
	            'post_status'         => 'publish',
	            'ignore_sticky_posts' => 0,
	            'orderby'             => 'title',
	            'order'               => 'ASK',
	            'posts_per_page'      => -1,
	        ));

	        if($et_footer->have_posts()){
	        	while($et_footer->have_posts()) : $et_footer->the_post();

	        		$footer_id    = get_the_ID();
	        		$footer_title = get_the_title($footer_id);

	        		$footers_array[$footer_id] = $footer_title;

	        	endwhile;
	        	wp_reset_postdata();
	        }

	        $cmb_page_layout->add_field( array(
				'name'             => esc_html__( 'Footer', 'themefushion-addons' ),
				'id'               => $prefix . 'footer',
				'type'             => 'select',
				'classes'          => 'select-230',
				'options'          => $footers_array,
				'default' => 'inherit',
			) );

		/*  Title section
		/*-------------------*/

			$title_sections_array = array(
				'none'    => esc_html__( 'None', 'themefushion-addons' ),
				'default' => esc_html__( 'Default', 'themefushion-addons' ),
				'inherit' => esc_html__( 'Inherit', 'themefushion-addons' ),
			);

			$et_title_section = new WP_Query(array(
	            'post_type'           => 'title_section',
	            'post_status'         => 'publish',
	            'ignore_sticky_posts' => 0,
	            'orderby'             => 'title',
	            'order'               => 'ASK',
	            'posts_per_page'      => -1,
	        ));

	        if($et_title_section->have_posts()){
	        	while($et_title_section->have_posts()) : $et_title_section->the_post();

	        		$title_section_id    = get_the_ID();
	        		$title_section_title = get_the_title($title_section_id);

	        		$title_sections_array[$title_section_id] = $title_section_title;

	        	endwhile;
	        	wp_reset_postdata();
	        }

	        $cmb_page_layout->add_field( array(
				'name'             => esc_html__( 'Title section', 'themefushion-addons' ),
				'id'               => $prefix . 'title_section',
				'type'             => 'select',
				'classes'          => 'select-230',
				'options'          => $title_sections_array,
				'default'          => 'inherit',
				'description'      => esc_html__( 'If you want to display slider instead of title section, set the title section to "None" and choose slider below. Note that slider has higher priority, i.e. if slider is active the title section is inactive.', 'themefushion-addons' ),
			) );

		/*  Slider
		/*-------------------*/

			$slider_array = array(
				'none'    => esc_html__( 'None', 'themefushion-addons' ),
			);

			if(shortcode_exists("rev_slider")){
	            $slider = new RevSlider();
	            $revolution_sliders = $slider->getArrSliders();
	            if ($revolution_sliders) {
	                foreach ( $revolution_sliders as $revolution_slider ) {
	                   $alias = $revolution_slider->getAlias();
	                   $title = $revolution_slider->getTitle();
	                   $slider_array[$alias] = $title;
	                }
	            }
	        }

	        $cmb_page_layout->add_field( array(
				'name'             => esc_html__( 'Slider', 'themefushion-addons' ),
				'id'               => $prefix . 'slider',
				'type'             => 'select',
				'classes'          => 'select-230',
				'options'          => $slider_array,
				'default'          => 'none',
				'description'      => esc_html__( 'Make sure the Revolution slider plugin is installed and active and at least one slider is created.', 'themefushion-addons' ),
			) );

	    $cmb_page_layout->add_field( array(
			'name'             => esc_html__( 'One page', 'themefushion-addons' ),
			'id'               => $prefix . 'one_page',
			'type'             => 'checkbox',
		) );

		/*  One page
		/*-------------------*/

			$cmb_page_layout->add_field( array(
			    'name' => esc_html__( 'Background options', 'themefushion-addons' ),
			    'desc' => esc_html__( 'Add custom background color, image or video', 'themefushion-addons' ),
			    'type' => 'title',
			    'id'   => 'back_options_title'
			) );

			$cmb_page_layout->add_field( array(
			    'name'    => esc_html__( 'Background color', 'themefushion-addons' ),
			    'id'      => $prefix . 'page_back_color',
			    'type'    => 'colorpicker',
			    'options' => array(
			        'alpha' => false, // Make this a rgba color picker.
			    ),
			) );

			$cmb_page_layout->add_field( array(
				'name'    => esc_html__( 'Background image', 'themefushion-addons' ),
				'id'      => $prefix . 'page_back_image',
				'type'    => 'file',
				'query_args' => array(
					'image/gif',
            		'image/jpeg',
            		'image/png'
				),
				'options' => array(
			        'url' => false
			    ),
			) );

			$cmb_page_layout->add_field( array(
				'name'    => esc_html__( 'MP4 video background', 'themefushion-addons' ),
				'desc'    => esc_html__( 'Upload an MP4 video file or enter an URL.', 'themefushion-addons' ),
				'id'      => $prefix . 'page_back_video',
				'type'    => 'file',
				'query_args' => array(
					'type' => 'video/mp4',
				)
			) );

	/*  Posts
	/*-------------------*/

		$cmb_post_layout = new_cmb2_box( array(
			'id'            => $prefix.'post_options_metabox',
			'title'         => esc_html__( 'Post options', 'themefushion-addons' ),
			'object_types'  => array( 'post', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_post_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_post_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

		$cmb_post_layout->add_field( array(
			'name'             => esc_html__( 'Disable featured image on single post page?', 'themefushion-addons' ),
			'description'      => esc_html__( 'If active, your image will not be visible in single post page', 'themefushion-addons' ),
			'id'               => $prefix . 'disable_image',
			'type'             => 'checkbox',
		) );

		$cmb_post_layout->add_field( array(
			'name'             => esc_html__( 'Link url', 'themefushion-addons' ),
			'id'               => $prefix . 'link',
			'classes'          => 'post-data link-format',
			'type'             => 'text_url',
		) );

		$cmb_post_layout->add_field( array(
			'name'             => esc_html__( 'Status author', 'themefushion-addons' ),
			'id'               => $prefix . 'status',
			'classes'          => 'post-data status-format',
			'type'             => 'text_medium',
		) );

		$cmb_post_layout->add_field( array(
			'name'             => esc_html__( 'Quote author', 'themefushion-addons' ),
			'id'               => $prefix . 'quote',
			'classes'          => 'post-data quote-format',
			'type'             => 'text_medium',
		) );

		$cmb_post_layout->add_field( array(
			'name'    => esc_html__( 'Format gallery', 'themefushion-addons' ),
			'id'      => $prefix . 'gallery',
			'type'    => 'file_list',
			'classes' => 'gallery-format post-data',
			'preview_size' => array( 100, 100 ),
			'query_args' => array( 'type' => 'image' ),
		) );

		$cmb_post_layout->add_field( array(
			'name'    => esc_html__( 'MP3 audio file', 'themefushion-addons' ),
			'desc'    => esc_html__( 'Upload an MP3 audio file or enter an URL.', 'themefushion-addons' ),
			'id'      => $prefix . 'audio',
			'classes' => 'audio-format post-data',
			'type'    => 'file',
			'query_args' => array(
				'type' => 'audio/mp3',
			)
		) );

		$cmb_post_layout->add_field( array(
			'name'    => esc_html__( 'Audio embed', 'themefushion-addons' ),
			'id'   => $prefix . 'audio_embed',
			'classes' => 'audio-format post-data',
			'type' => 'oembed',
		) );

		$cmb_post_layout->add_field( array(
			'name'    => esc_html__( 'MP4 video file', 'themefushion-addons' ),
			'desc'    => esc_html__( 'Upload an MP4 video file or enter an URL.', 'themefushion-addons' ),
			'id'      => $prefix . 'video',
			'classes' => 'video-format post-data',
			'type'    => 'file',
			'query_args' => array(
				'type' => 'video/mp4',
			)
		) );

		$cmb_post_layout->add_field( array(
			'name'    => esc_html__( 'Video embed', 'themefushion-addons' ),
			'id'      => $prefix . 'video_embed',
			'classes' => 'video-format post-data',
			'type'    => 'oembed',
		) );

	/*  Products
	/*-------------------*/

		$cmb_products_layout = new_cmb2_box( array(
			'id'            => $prefix.'products_options_metabox',
			'title'         => esc_html__( 'Products options', 'themefushion-addons' ),
			'object_types'  => array( 'product', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true
		) );

		$cmb_products_layout->add_field( array(
			'name' => esc_html__( 'Wishlist', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => $prefix .'wishlist',
		));

		$cmb_products_layout->add_field( array(
			'name' => esc_html__( 'Element css', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css',
		));

		$cmb_products_layout->add_field( array(
			'name' => esc_html__( 'Element css responsive', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_css_resp',
		));

		$cmb_products_layout->add_field( array(
			'name' => esc_html__( 'Element font', 'themefushion-addons' ),
			'type' => 'hidden',
			'id'   => 'element_font',
		));

}
