<?php

	function themefushion_addons_header() {

		$labels = array(
			'name'               => esc_html__('Headers', 'themefushion-addons'),
			'singular_name'      => esc_html__('Headers', 'themefushion-addons'),
			'add_new'            => esc_html__('Add new', 'themefushion-addons'),
			'add_new_item'       => esc_html__('Add new header', 'themefushion-addons'),
			'edit_item'          => esc_html__('Edit header', 'themefushion-addons'),
			'new_item'           => esc_html__('New header', 'themefushion-addons'),
			'all_items'          => esc_html__('All headers', 'themefushion-addons'),
			'view_item'          => esc_html__('View header', 'themefushion-addons'),
			'search_items'       => esc_html__('Search header', 'themefushion-addons'),
			'not_found'          => esc_html__('No header found', 'themefushion-addons'),
			'not_found_in_trash' => esc_html__('No header found in trash', 'themefushion-addons'), 
			'parent_item_colon'  => '',
			'menu_name'          => esc_html__('Headers', 'themefushion-addons')
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'exclude_from_search'=> true,
			'show_ui'            => true, 
			'show_in_menu'       => true, 
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'header','with_front' => false ),
			'capability_type'    => 'post',
			'has_archive'        => false, 
			'hierarchical'       => false,
			'menu_position'      => 50,
			'menu_icon'          => 'dashicons-star-filled',
			'supports'           => array( 'title', 'editor'),
		);

		register_post_type( 'header', $args );
	}

	add_action( 'init', 'themefushion_addons_header');


	add_filter("manage_edit-header_columns", "themefushion_addons_header_edit_columns");
	function themefushion_addons_header_edit_columns($columns){
		$columns['cb']     = "<input type=\"checkbox\" />";
		$columns['title']  = esc_html__("Title", 'themefushion-addons');
        $columns['type']   = esc_html__("Type", 'themefushion-addons');
        $columns['visibility'] = esc_html__("Visibility", 'themefushion-addons');

		unset($columns['comments']);
		return $columns;
	}

	add_action("manage_header_posts_custom_column", "themefushion_addons_header_custom_columns");
	function themefushion_addons_header_custom_columns($column){
		global $post, $mobimab_themefushion;

        $desktop_header_id = (isset($GLOBALS['mobimab_themefushion']['header-desktop-id']) && !empty($GLOBALS['mobimab_themefushion']['header-desktop-id'])) ? $GLOBALS['mobimab_themefushion']['header-desktop-id'] : "none";
        $mobile_header_id  = (isset($GLOBALS['mobimab_themefushion']['header-mobile-id']) && !empty($GLOBALS['mobimab_themefushion']['header-mobile-id'])) ? $GLOBALS['mobimab_themefushion']['header-mobile-id'] : "none";


        $type               = get_post_meta( $post->ID, 'themefushion_addons_header_type', true );
        $mobile             = get_post_meta( $post->ID, 'themefushion_addons_mobile', true );
        $tablet_portrait    = get_post_meta( $post->ID, 'themefushion_addons_tablet_portrait', true );
        $tablet_landscape   = get_post_meta( $post->ID, 'themefushion_addons_tablet_landscape', true );
        $desktop            = get_post_meta( $post->ID, 'themefushion_addons_desktop', true );

        $active_header_text   = '';
        $main_header_text     = esc_html__("This header is set as site main desktop header", 'themefushion-addons');
        $color_indicator_type = 'indicator-1';

        if ($type == "mobile") {
            $color_indicator_type = 'indicator-2';
        }

        if ($type == "sidebar") {
            $color_indicator_type = 'indicator-4';
        }

		switch ($column){
			case "type":
    			echo '<div class="custom-meta-ind '.$color_indicator_type.'">'.$type.'</div>';
                if ($post->ID == $desktop_header_id || $post->ID == $mobile_header_id) {
                    if ($post->ID == $mobile_header_id && $post->ID != $desktop_header_id) {
                        $main_header_text   = esc_html__("This header is set as site main mobile header", 'themefushion-addons');
                    }
                    echo '<span class="custom-meta-ind header-active indicator-5" title="'.$main_header_text.'">'.esc_html__("active", 'themefushion-addons').'</span>';
                }
            break;
            case "visibility":
                if ($mobile == "on") {
                    echo '<div class="custom-meta-ind indicator-3">'.esc_html__("Mobile", 'themefushion-addons').'</div>';
                }
                if ($tablet_portrait == "on") {
                    echo '<div class="custom-meta-ind indicator-3">'.esc_html__("Tablet portrait", 'themefushion-addons').'</div>';
                }
                if ($tablet_landscape == "on") {
                    echo '<div class="custom-meta-ind indicator-3">'.esc_html__("Tablet landscape", 'themefushion-addons').'</div>';
                }
                if ($desktop == "on") {
                    echo '<div class="custom-meta-ind indicator-3">'.esc_html__("Desktop", 'themefushion-addons').'</div>';
                }
            break;
		}
	}
?>