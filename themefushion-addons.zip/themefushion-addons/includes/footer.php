<?php

	function themefushion_addons_footer() {

		$labels = array(
			'name'               => esc_html__('Footers', 'themefushion-addons'),
			'singular_name'      => esc_html__('Footers', 'themefushion-addons'),
			'add_new'            => esc_html__('Add new', 'themefushion-addons'),
			'add_new_item'       => esc_html__('Add new footer', 'themefushion-addons'),
			'edit_item'          => esc_html__('Edit footer', 'themefushion-addons'),
			'new_item'           => esc_html__('New footer', 'themefushion-addons'),
			'all_items'          => esc_html__('All footers', 'themefushion-addons'),
			'view_item'          => esc_html__('View footer', 'themefushion-addons'),
			'search_items'       => esc_html__('Search footer', 'themefushion-addons'),
			'not_found'          => esc_html__('No footer found', 'themefushion-addons'),
			'not_found_in_trash' => esc_html__('No footer found in trash', 'themefushion-addons'), 
			'parent_item_colon'  => '',
			'menu_name'          => esc_html__('Footers', 'themefushion-addons')
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'exclude_from_search'=> true,
			'show_ui'            => true, 
			'show_in_menu'       => true, 
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'footer','with_front' => false ),
			'capability_type'    => 'post',
			'has_archive'        => false, 
			'hierarchical'       => false,
			'menu_position'      => 50,
			'menu_icon'          => 'dashicons-star-filled',
			'supports'           => array( 'title', 'editor'),
		);

		register_post_type( 'footer', $args );
	}

	add_action( 'init', 'themefushion_addons_footer');


	add_filter("manage_edit-footer_columns", "themefushion_addons_footer_edit_columns");
	function themefushion_addons_footer_edit_columns($columns){
		$columns['cb']             = "<input type=\"checkbox\" />";
		$columns['title']          = esc_html__("Title", 'themefushion-addons');
		$columns['active']         = esc_html__("Active footer", 'themefushion-addons');

		unset($columns['comments']);
		return $columns;
	}

	add_action("manage_footer_posts_custom_column", "themefushion_addons_footer_custom_columns");
	function themefushion_addons_footer_custom_columns($column){
		global $post, $mobimab_themefushion;

        $footer_id  = (isset($GLOBALS['mobimab_themefushion']['footer-id']) && !empty($GLOBALS['mobimab_themefushion']['footer-id'])) ? $GLOBALS['mobimab_themefushion']['footer-id'] : "none";

		switch ($column){
			case "active":
			if ($footer_id == $post->ID) {
				echo '<div class="custom-meta-ind active-footer">'.esc_html__("Active", 'themefushion-addons').'</div>';
			}
			break;
		}
	}

?>