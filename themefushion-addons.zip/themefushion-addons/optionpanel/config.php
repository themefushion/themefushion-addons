<?php

if ( ! class_exists( 'Redux' ) ) {
    return;
}

$opt_name = "mobimab_themefushion";
$theme    = wp_get_theme();

$args = array(
    'opt_name'             => $opt_name,
    'display_name'         => $theme->get( 'Name' ),
    'display_version'      => $theme->get( 'Version' ),
    'menu_type'            => 'submenu',
    'allow_sub_menu'       => true,
    'menu_title'           => esc_html__('Theme settings', 'themefushion-addons'),
    'page_title'           => esc_html__('Theme settings', 'themefushion-addons'),
    'google_api_key'       => 'AIzaSyD4_siUiwNbGDKcVNPQjCl-6eyzhctrPsM',
    'google_update_weekly' => true,
    'async_typography'     => true,
    'admin_bar'            => true,
    'admin_bar_icon'       => '',
    'admin_bar_priority'   => 50,
    'global_variable'      => 'mobimab_themefushion',
    'dev_mode'             => false,
    'update_notice'        => false,
    'customizer'           => false,
    'page_priority'        => null,
    'page_parent'          => 'themes.php',
    'page_permissions'     => 'manage_options',
    'menu_icon'            => '',
    'last_tab'             => '',
    'page_icon'            => 'icon-themes',
    'page_slug'            => 'themefushion',
    'save_defaults'        => true,
    'default_show'         => false,
    'default_mark'         => '',
    'show_import_export'   => false
);

Redux::setArgs( $opt_name, $args );

if ( ! function_exists( 'remove_demo' ) ) {
    function remove_demo() {
        if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
            remove_filter( 'plugin_row_meta', array(
                ReduxFrameworkPlugin::instance(),
                'plugin_metalinks'
            ), null, 2 );
            remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
        }
    }
}

$inc = 123;

/* General
---------------*/

    Redux::setSection( $opt_name, array(
		'title'      => esc_html__('General', 'themefushion-addons'),
		'id'         => esc_html__('sec_general', 'themefushion-addons'),
		'icon_class' => 'icon-small',
	    'icon'       => 'el-icon-wrench',
	    'fields' => array(
	    	array(
				'id'       =>'disable-plugins',
				'type'     => 'switch',
				'title'    => esc_html__('Disable recommended plugins', 'themefushion-addons'),
				"default"  => 0
			),
	    	array(
				'id'       =>'disable-gutenberg',
				'type'     => 'switch',
				'title'    => esc_html__('Disable gutenberg', 'themefushion-addons'),
				'subtitle' => esc_html__('By default WordPress comes with new block editor "Gutenberg". If you want classic editor or Visual Composer, make sure this option is active', 'themefushion-addons'),
				"default"  => 1
			),
			array(
				'id'       =>'disable-gutenberg-type',
				'type'     => 'checkbox',
				'title'    => esc_html__('Choose post types to disable Gutenberg', 'themefushion-addons'),
				'options'  => array(
			        'post' => esc_html__('Posts', 'themefushion-addons'),
			        'page' => esc_html__('Pages', 'themefushion-addons'),
			        'product' => esc_html__('Products', 'themefushion-addons'),
			        'widgets' => esc_html__('Widgets', 'themefushion-addons'),
			    ),
			    'default' => array(
			        'post' => '0',
			        'page' => '1',
			        'widgets' => '1',
			        'product' => '0'
    			),
			    'required' => array('disable-gutenberg','equals',1)
			),
	    	array(
				'id'       =>'disable-defaults',
				'type'     => 'switch',
				'class'    => 'hidden-field',
				'title'    => esc_html__('Turn off default styling', 'themefushion-addons'),
				"default"  => 1
			),
			array(
				'id'       =>'plugins-combined',
				'type'     => 'switch',
				'title'    => esc_html__('Load combined js plugins file', 'themefushion-addons'),
				"default"  => 1
			),
	    	array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('Colors', 'themefushion-addons')
			),
			array(
				'id'       =>'main-color',
				'type'     => 'color',
				'title'    => esc_html__('Main color', 'themefushion-addons'),
				'default'  => '#ffb700',
                'transparent' => false
			),
			array(
				'id'       =>'area-color',
				'type'     => 'color',
				'title'    => esc_html__('Area color', 'themefushion-addons'),
				'default'  => '#e0f1fb',
                'transparent' => false
			),
			array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('Layout settings', 'themefushion-addons')
			),
	    	array(
				'id'        =>'layout',
				'type'      => 'radio',
				'title'     => esc_html__('Layout', 'themefushion-addons'),
				'subtitle'  => esc_html__('Boxed layout allows you to display the whole website in the box. (works on screens larger than 1200px wide). Make sure your navigation is not sidebar', 'themefushion-addons'),
				'options'   => array(
					'wide'  => esc_html__('Wide', 'themefushion-addons'),
					'boxed' => esc_html__('Boxed', 'themefushion-addons'),
				),
				'default' => 'wide',
			),
			array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('Site background settings', 'themefushion-addons'),
			    'required' => array('layout','equals','boxed')
			),
	    	array(
				'id'       =>'site-background',
				'type'     => 'background',
				'title'    => esc_html__('Site background options', 'themefushion-addons'),
				'required' => array('layout','equals','boxed')
			),
			array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('Footer settings', 'themefushion-addons')
			),
			array(
				'id'   => 'warning-info-'.$inc++,
				'class'=> 'warning-info',
				'type' => 'info',
				'style' => 'warning',
				'desc' => esc_html__('Important! If you do not see any option, first you must', 'themefushion-addons').' <a href="'.esc_url(home_url('/')).'wp-admin/post-new.php?post_type=footer">'.esc_html__("create a footer", "themefushion-addons").'</a>'
			),
			array(
				'id'=>'footer-id',
				'type' => 'select',
				'data' => 'posts',
				'args' => array('post_type' => 'footer', 'posts_per_page' => -1),
				'title'    => esc_html__('Footer', 'themefushion-addons'),
			),
			array(
				'id'=>'footer-id-wpml',
				'type' => 'text',
				'class'    => 'wpml-on',
				'title'    => esc_html__('WPML footer per language', 'themefushion-addons'),
				'description'    => esc_html__('Specify footer for each language with the following format language code:footer id, separate multiple by | (example: en:7846|de:54568)', 'themefushion-addons'),
			),
			array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('Header settings', 'themefushion-addons')
			),
			array(
				'id'   => 'warning-info-'.$inc++,
				'class'=> 'warning-info',
				'type' => 'info',
				'style' => 'warning',
				'desc' => esc_html__('Important! If you do not see any option, first you must', 'themefushion-addons').' <a href="'.esc_url(home_url('/')).'wp-admin/post-new.php?post_type=header">'.esc_html__("create a header", "themefushion-addons").'</a>'
			),
			array(
				'id'=>'header-desktop-id',
				'type' => 'select',
				'data' => 'posts',
				'args' => array('post_type' => 'header', 'posts_per_page' => -1),
				'title'    => esc_html__('Desktop header', 'themefushion-addons'),
			),
			array(
				'id'=>'header-desktop-id-wpml',
				'type' => 'text',
				'class'    => 'wpml-on',
				'title'    => esc_html__('WPML desktop header per language', 'themefushion-addons'),
				'description'    => esc_html__('Specify desktop header for each language with the following format language code:header id, separate multiple by | (example: en:7846|de:54568)', 'themefushion-addons'),
			),
			array(
				'id'=>'header-mobile-id',
				'type' => 'select',
				'data' => 'posts',
				'args' => array('post_type' => 'header', 'posts_per_page' => -1),
				'title'    => esc_html__('Mobile header', 'themefushion-addons'),
			),
			array(
				'id'=>'header-mobile-id-wpml',
				'type' => 'text',
				'class'    => 'wpml-on',
				'title'    => esc_html__('WPML mobile header per language', 'themefushion-addons'),
				'description'    => esc_html__('Specify mobile header for each language with the following format language code:header id, separate multiple by | (example: en:7846|de:54568)', 'themefushion-addons'),
			),
			array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('Page title section settings', 'themefushion-addons')
			),
			array(
				'id'   => 'warning-info-'.$inc++,
				'class'=> 'warning-info',
				'type' => 'info',
				'style' => 'warning',
				'desc' => esc_html__('Important! If you do not see any option, first you must', 'themefushion-addons').' <a href="'.esc_url(home_url('/')).'wp-admin/post-new.php?post_type=title_section">'.esc_html__("create a title section", "themefushion-addons").'</a>'
			),
			array(
				'id'=>'title-section-id',
				'type' => 'select',
				'data' => 'posts',
				'args' => array('post_type' => 'title_section', 'posts_per_page' => -1),
				'title'    => esc_html__('Page title section', 'themefushion-addons'),
			),
			array(
				'id'=>'title-section-id-wpml',
				'type' => 'text',
				'class'    => 'wpml-on',
				'title'    => esc_html__('WPML title section per language', 'themefushion-addons'),
				'description'    => esc_html__('Specify title section for each language with the following format language code:title section id, separate multiple by | (example: en:7846|de:54568)', 'themefushion-addons'),
			),
			array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('One page navigation settings', 'themefushion-addons')
			),
			array(
				'id'       =>'one-page-filter',
				'type'     => 'text',
				'title'    => esc_html__('One page menu filter', 'themefushion-addons'),
				'subtitle'=> esc_html__("Exclude links from one page menu by entering comma-separated menu items' ids", 'themefushion-addons'),
			),
			array(
			    'id'   => 'info_normal_'.$inc++,
				'class'=> 'info-normal',
			    'type' => 'info',
			    'desc' => esc_html__('API settings', 'themefushion-addons')
			),
			array(
				'id'      =>'mailchimp-api-key',
				'type'     => 'text',
				'title'    => esc_html__('Mailchimp API key', 'themefushion-addons'),
				'subtitle' => esc_html__("If you are not sure how to retrieve this, follow this link from MailChimp Knowledge Base to retrieve your account's API key", 'themefushion-addons').' <a href="http://kb.mailchimp.com/accounts/management/about-api-keys#Finding-or-generating-your-API-key" target="_blank">'.esc_html__("Retrieve your account's API key", 'themefushion-addons').'</a>',
			),
			array(
				'id'       =>'flickr-api',
				'type'     => 'text',
				'title'    => esc_html__("Flickr API Key", 'themefushion-addons'),
				'subtitle' => esc_html__("If you are not sure how to retrieve this, follow this link from Flickr Knowledge Base to retrieve your account's API key", 'themefushion-addons').' <a href="https://www.flickr.com/services/developer/api/" target="_blank">'.esc_html__("Retrieve your account's API key", 'themefushion-addons').'</a>',
			),
			array(
				'id'       =>'mtt',
				'type'     => 'switch',
				'title'    => esc_html__('Move to top arrow', 'themefushion-addons'),
				'subtitle' => esc_html__('Toggle this option if you want to have move to top arrow', 'themefushion-addons'),
				"default"  => 1
			)
	    )
	));

/* CSS
---------------*/

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__('CSS', 'themefushion-addons'),
		'icon_class' => 'icon-small',
	    'icon'       => 'el-icon-star',
	    'fields'     => array(
	    	array(
	            'id'       => 'custom-css',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				// 'class'    => 'hidden-field',
				'theme'    => 'monokai',
	            'title'    => esc_html__('Custom CSS Styles', 'themefushion-addons'),
	            'subtitle' => esc_html__('Enter custom css code here.', 'themefushion-addons')
	        ),
	        array(
	            'id'       => 'custom-css-max-374',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(max-width: 374px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-min-375',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(min-width: 375px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-min-375-max-767',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(min-width: 375px) and (max-width: 767px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-max-767',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(max-width: 767px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-min-768',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(min-width: 768px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-min-768-max-1023',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(min-width: 768px) and (max-width: 1023px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-max-1023',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(max-width: 1023px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-min-1024',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(min-width: 1024px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-min-1024-max-1279',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(min-width: 1024px) and (max-width: 1279px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-max-1279',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(max-width: 1279px)', 'themefushion-addons'),
	        ),
	        array(
	            'id'       => 'custom-css-min-1280',
	            'type'     => 'ace_editor',
				'mode'     => 'css',
				'theme'    => 'monokai',
	            'title'    => esc_html__('(min-width: 1280px)', 'themefushion-addons'),
	        ),
	    )
	));

/* Typography
---------------*/

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__('Typography', 'themefushion-addons'),
		'icon_class' => 'icon-small',
	    'icon'       => 'el-icon-font',
	    'fields'     => array(
	    	array(
				'id'       =>'main-typo',
				'type'     => 'typography',
				'title'    => esc_html__('Main typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => false,
				'letter-spacing' => true,
				'font-style'     => false,
				'font-weight'    => true,
				'color'          => true,
				'text-align'     => false,
				'font-family'    => true,
				'default'     => array(
					'font-family'    => 'Heebo',
			        'font-size'      => '14px',
			        'font-weight'    => '400',
			        'line-height'    => '24px',
			        'letter-spacing' => '0',
			        'color'          => '#616161',
			    )
			),

			array(
				'id'       =>'headings-typo',
				'type'     => 'typography',
				'title'    => esc_html__('Headings typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => true,
				'letter-spacing' => true,
				'line-height'    => false,
				'font-style'     => false,
				'font-size'      => false,
				'font-weight'    => true,
				'color'          => true,
				'text-align'     => false,
				'font-family'    => true,
				'default'     => array(
					'font-family'    => 'Heebo',
			        'font-weight'    => '700',
			        'letter-spacing' => '0',
			        'color'          => '#1c1c1e'
			    )
			),

			array(
				'id'       =>'h1-typo',
				'type'     => 'typography',
				'title'    => esc_html__('H1 typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => false,
				'letter-spacing' => false,
				'line-height'    => true,
				'font-style'     => false,
				'font-size'      => true,
				'font-weight'    => false,
				'color'          => false,
				'text-align'     => false,
				'font-family'    => false,
				'default'     => array(
			        'font-size'   => '48px',
			        'line-height' => '52px'
			    )
			),

			array(
				'id'       =>'h2-typo',
				'type'     => 'typography',
				'title'    => esc_html__('H2 typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => false,
				'letter-spacing' => false,
				'line-height'    => true,
				'font-style'     => false,
				'font-size'      => true,
				'font-weight'    => false,
				'color'          => false,
				'text-align'     => false,
				'font-family'    => false,
				'default'     => array(
			        'font-size'   => '40px',
			        'line-height' => '46px'
			    )
			),

			array(
				'id'       =>'h3-typo',
				'type'     => 'typography',
				'title'    => esc_html__('H3 typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => false,
				'letter-spacing' => false,
				'line-height'    => true,
				'font-style'     => false,
				'font-size'      => true,
				'font-weight'    => false,
				'color'          => false,
				'text-align'     => false,
				'font-family'    => false,
				'default'     => array(
			        'font-size'   => '32px',
			        'line-height' => '36px'
			    )
			),

			array(
				'id'       =>'h4-typo',
				'type'     => 'typography',
				'title'    => esc_html__('H4 typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => false,
				'letter-spacing' => false,
				'line-height'    => true,
				'font-style'     => false,
				'font-size'      => true,
				'font-weight'    => false,
				'color'          => false,
				'text-align'     => false,
				'font-family'    => false,
				'default'     => array(
			        'font-size'   => '24px',
			        'line-height' => '32px'
			    )
			),

			array(
				'id'       =>'h5-typo',
				'type'     => 'typography',
				'title'    => esc_html__('H5 typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => false,
				'letter-spacing' => false,
				'line-height'    => true,
				'font-style'     => false,
				'font-size'      => true,
				'font-weight'    => false,
				'color'          => false,
				'text-align'     => false,
				'font-family'    => false,
				'default'     => array(
			        'font-size'   => '20px',
			        'line-height' => '28px'
			    )
			),

			array(
				'id'       =>'h6-typo',
				'type'     => 'typography',
				'title'    => esc_html__('H6 typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'text-transform' => false,
				'letter-spacing' => false,
				'line-height'    => true,
				'font-style'     => false,
				'font-weight'    => false,
				'font-size'      => true,
				'color'          => false,
				'text-align'     => false,
				'font-family'    => false,
				'default'     => array(
			        'font-size'   => '18px',
			        'line-height' => '26px'
			    )
			),
        )
	));

/* Forms
---------------*/

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__('Forms', 'themefushion-addons'),
		'icon_class' => 'icon-small',
	    'icon'       => 'el-icon-tasks',
	    'fields'     => array(
			array(
				'id'       =>'form-text-color',
				'type'     => 'link_color',
				'title'    => esc_html__('Forms fields text colors', 'themefushion-addons'),
				'visited'  => false,
				'active'    => false,
				'default'  => array(
			        'regular' => '#616161',
			        'hover'   => '#616161',
			    )
			),
			array(
				'id'       =>'form-back-color',
				'type'     => 'link_color',
				'title'    => esc_html__('Forms fields background colors', 'themefushion-addons'),
				'visited'  => false,
				'active'    => false,
				'default'   => array(
			        'regular' => '#ffffff',
			        'hover'   => '#ffffff',
			    )
			),
			array(
				'id'       =>'form-border-color',
				'type'     => 'link_color',
				'title'    => esc_html__('Forms fields border colors', 'themefushion-addons'),
				'visited'  => false,
				'active'    => false,
				'default'   => array(
			        'regular' => '#eaeaea',
			        'hover'   => '#eaeaea',
			    )
			),
			array(
				'id'       =>'form-button-typo',
				'type'     => 'typography',
				'title'    => esc_html__('Button typography', 'themefushion-addons'),
				'units'          => 'px',
				'google'         => true,
				'subsets'        => true,
				'all_styles'     => true,
				'font-weight'    => true,
				'font-size'      => false,
				'font-family'    => true,
				'letter-spacing' => true,
				'text-transform' => true,
				'line-height'    => false,
				'font-style'     => false,
				'color'          => false,
				'text-align'     => false,
				'text-transform' => false,
				'word-spacing'   => false,
				'default'     => array(
					'font-weight'    => '500',
					'font-family'    => 'Heebo',
					'letter-spacing' => '0',
			    )
			),
			array(
				'id'       => 'form-button-back',
				'type'     => 'link_color',
				'active'   => false,
				'visited'  => false,
				'title'    => esc_html__('Button background colors', 'themefushion-addons'),
				'default'  => array(
					'regular'  => '#ffb700',
					'hover'    => '#1c1c1e'
				)
			),
			array(
				'id'       =>'form-button-color',
				'type'     => 'link_color',
				'active'   => false,
				'visited'  => false,
				'title'    => esc_html__('Button text colors', 'themefushion-addons'),
				'default'  => array(
					'regular'  => '#000000',
					'hover'    => '#ffffff'
				)
			),
		)
	));

/* Blog
---------------*/

	global $wpdb;

	$querystr = "
	    SELECT $wpdb->posts.*
	    FROM $wpdb->posts, $wpdb->postmeta
	    WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id
	    AND $wpdb->posts.post_status = 'publish'
	    AND $wpdb->posts.post_type = 'title_section'
	    ORDER BY $wpdb->posts.post_title ASC
	";

	$title_sections = $wpdb->get_results($querystr, OBJECT);

	$title_sections_array = array(
		'none'    => esc_html__( 'None', 'themefushion-addons' ),
		'default' => esc_html__( 'Default', 'themefushion-addons' ),
		'inherit' => esc_html__( 'Inherit', 'themefushion-addons' ),
	);

    if($title_sections){

    	foreach ($title_sections as $title_section) {
    		$title_section_id    = $title_section->ID;
    		$title_section_title = $title_section->post_title;
    		$title_sections_array[$title_section_id] = $title_section_title;
    	}

    }

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__('Blog', 'themefushion-addons'),
		'icon_class' => 'icon-small',
	    'icon'       => 'el-icon-pencil',
	    'fields' => array(
			array(
				'id'=>'blog-title',
				'type' => 'select',
				'title' => esc_html__('Choose title section', 'themefushion-addons'),
				'options' => $title_sections_array,
				'default' => 'inherit',
			),
			array(
				'id'=>'blog-title-single',
				'type' => 'select',
				'title' => esc_html__('Choose title section for single post pages', 'themefushion-addons'),
				'options' => $title_sections_array,
				'default' => 'inherit',
			),
			array(
				'id'      =>'blog-title-text',
				'type'    => 'text',
				'title'   => esc_html__('Blog title', 'themefushion-addons'),
				'default' => 'Blog',
			),
			array(
				'id'      =>'blog-subtitle-text',
				'type'    => 'text',
				'title'   => esc_html__('Blog subtitle', 'themefushion-addons'),
				'default' => '',
			),
			array(
				'id'        =>'blog-sidebar',
				'type'      => 'select',
				'title'     => esc_html__('Blog sidebar position', 'themefushion-addons'),
				'options'   => array(
					'none'  => esc_html__('None', 'themefushion-addons'),
					'left'  => esc_html__('Left', 'themefushion-addons'),
					'right' => esc_html__('Right', 'themefushion-addons'),
				),
				'default' => 'none',
			),
			array(
				'id'        =>'blog-navigation',
				'type'      => 'select',
				'title'     => esc_html__('Blog navigation', 'themefushion-addons'), 
				'options'   => array(
					'pagination' => esc_html__('Pagination', 'themefushion-addons'), 
					'loadmore'   => esc_html__('Load more', 'themefushion-addons'), 
					'infinite'   => esc_html__('Infinite load', 'themefushion-addons'),
				),
				'default' => 'pagination',
			),
			array(
				'id'       => 'blog-post-layout',
				'type'     => 'image_select',
				'title'    => esc_html__('Blog post layout', 'themefushion-addons'),
				'width'    => '140',
				'height'   => '140',
				'options'  => array(
					'grid' => array(
						'alt'   => esc_html__('Grid', 'themefushion-addons'),
						'title' => esc_html__('Grid', 'themefushion-addons'),
						'img'   => THEME_IMG.'grid.png'
					),
					'masonry' => array(
						'alt'   => esc_html__('Masonry', 'themefushion-addons'),
						'title' => esc_html__('Masonry', 'themefushion-addons'),
						'img'   => THEME_IMG.'masonry.png'
					),
					'list' => array(
						'alt'   => esc_html__('List', 'themefushion-addons'),
						'title' => esc_html__('List', 'themefushion-addons'),
						'img'   => THEME_IMG.'list.png'
					),
					'full' => array(
						'alt'   => esc_html__('Full', 'themefushion-addons'),
						'title' => esc_html__('Full', 'themefushion-addons'),
						'img'   => THEME_IMG.'full.png'
					),
				),
				'default' => 'masonry'
			),
			array(
				'id'       =>'blog-image-full',
				'type'     => 'switch',
				'title'    => esc_html__('Use original image size (no cropping)', 'themefushion-addons'),
				"default"  => 0,
				'required' => array('blog-post-layout','equals',array('grid','masonry'))
			),
			array(
				'id'       =>'blog-post-title-excerpt',
				'type'     => 'slider',
				'title'    => esc_html__('Blog post title excerpt length', 'themefushion-addons'),
				'min'      =>'0',
				'max'      =>'500',
				'step'     =>'1',
				'default'  => '52',
			),
			array(
				'id'       =>'blog-post-excerpt',
				'type'     => 'slider',
				'title'    => esc_html__('Blog post excerpt length', 'themefushion-addons'),
				'min'      =>'0',
				'max'      =>'500',
				'step'     =>'1',
				'default'  => '0',
			),
			array(
				'id'        =>'blog-single-sidebar',
				'type'      => 'select',
				'title'     => esc_html__('Blog single post sidebar position', 'themefushion-addons'),
				'options'   => array(
					'none'  => esc_html__('None', 'themefushion-addons'),
					'left'  => esc_html__('Left', 'themefushion-addons'),
					'right' => esc_html__('Right', 'themefushion-addons'),
				),
				'default' => 'none',
			),
			array(
				'id'       =>'blog-single-social',
				'type'     => 'switch',
				'title'    => esc_html__('Blog single post social share', 'themefushion-addons'),
				"default"  => 0
			),
			array(
				'id'       =>'blog-related-posts',
				'type'     => 'switch',
				'title'    => esc_html__('Blog single post related posts', 'themefushion-addons'),
				"default"  => 1
			),
			array(
				'id'        =>'blog-related-posts-by',
				'type'      => 'select',
				'title'     => esc_html__('Related posts by', 'themefushion-addons'),
				'options'   => array(
					'categories'  => esc_html__('Categories', 'themefushion-addons'),
					'tags'  => esc_html__('Tags', 'themefushion-addons'),
				),
				'default' => 'categories',
				'required' => array('blog-related-posts','equals',1)
			),
			array(
				'id'       =>'blog-authorbox',
				'type'     => 'switch',
				'title'    => esc_html__('Blog single post author box', 'themefushion-addons'),
				"default"  => 1
			),
		)
	));

/* Woo Commerce
---------------*/

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__('Shop', 'themefushion-addons'),
		'icon_class' => 'icon-small',
	    'icon'       => 'el-icon-shopping-cart',
	    'fields' => array(
			array(
				'id'=>'product-title',
				'type' => 'select',
				'title'    => esc_html__('Choose title section', 'themefushion-addons'),
				'options' => $title_sections_array,
				'default' => 'inherit',
			),
			array(
				'id'=>'product-title-single',
				'type' => 'select',
				'title' => esc_html__('Choose title section for single product pages', 'themefushion-addons'),
				'options' => $title_sections_array,
				'default' => 'inherit',
			),
			array(
				'id'      =>'product-title-text',
				'type'     => 'text',
				'title'    => esc_html__('Shop title', 'themefushion-addons'),
				'default'  => 'Shop',
			),
			array(
				'id'      =>'product-subtitle-text',
				'type'     => 'text',
				'title'    => esc_html__('Shop subtitle', 'themefushion-addons'),
				'default'  => '',
			),
			array(
				'id'        =>'product-sidebar',
				'type'      => 'select',
				'title'     => esc_html__('Shop sidebar position', 'themefushion-addons'),
				'options'   => array(
					'none'  => esc_html__('None', 'themefushion-addons'),
					'left'  => esc_html__('Left', 'themefushion-addons'),
					'right' => esc_html__('Right', 'themefushion-addons'),
				),
				'default' => 'none',
			),
			array(
				'id'       =>'product-per-page',
				'type'     => 'slider',
				'title'    => esc_html__('Products per page', 'themefushion-addons'),
				'min'      =>'0',
				'max'      =>'999',
				'step'     =>'1',
				'default'  => '9'
			),
			array(
				'id'       =>'product-navigation',
				'type'     => 'select',
				'title'    => esc_html__('Shop navigation', 'themefushion-addons'),
				'subtitle' => esc_html__('Shop navigation', 'themefushion-addons'),
				'options'  => array(
					'pagination' => esc_html__('Pagination', 'themefushion-addons'), 
					'loadmore'   => esc_html__('Load more', 'themefushion-addons'), 
					'infinite'   => esc_html__('Infinite load', 'themefushion-addons'),
				),
				'default'  => 'pagination'
			),
			array(
				'id'        =>'product-post-layout',
				'type'      => 'select',
				'title'     => esc_html__('Product layout', 'themefushion-addons'),
				'options'   => array(
					'list'  => esc_html__('List', 'themefushion-addons'),
					'grid'  => esc_html__('Grid', 'themefushion-addons'),
					'comp' => esc_html__('Full', 'themefushion-addons'),
				),
				'default' => 'grid',
			),
			array(
				'id'       =>'product-gap',
				'type'     => 'switch',
				'title'    => esc_html__('Gap between products', 'themefushion-addons'),
				"default"  => 0,
				'required' => array('product-post-layout','equals','grid')
			),
			array(
				'id'        =>'product-post-size',
				'type'      => 'select',
				'title'     => esc_html__('Product size', 'themefushion-addons'),
				'options'   => array(
					'small'  => esc_html__('Small', 'themefushion-addons'),
					'medium' => esc_html__('Medium', 'themefushion-addons'),
					'large'  => esc_html__('Large (grid only)', 'themefushion-addons'),
				),
				'default' => 'medium',
				'required' => array('product-post-layout','equals',array('grid','list'))
			),
			array(
				'id'       =>'product-title-excerpt',
				'type'     => 'slider',
				'title'    => esc_html__('Product title excerpt length', 'themefushion-addons'),
				'min'      =>'0', 
				'max'      =>'500', 
				'step'     =>'1',
				'default'  => '500'
			),
			array(
				'id'       =>'product-title-min-height',
				'type'     => 'slider',
				'title'    => esc_html__('Product title minimum height', 'themefushion-addons'),
				'min'      =>'0', 
				'max'      =>'500', 
				'step'     =>'1',
				'default'  => '36'
			),
			array(
				'id'       =>'product-title-max-height',
				'type'     => 'slider',
				'title'    => esc_html__('Product title maximum height', 'themefushion-addons'),
				'min'      =>'0', 
				'max'      =>'500', 
				'step'     =>'1',
				'default'  => '36'
			),
			array(
				'id'       =>'product-image-full',
				'type'     => 'switch',
				'title'    => esc_html__('Use original image size (no cropping)', 'themefushion-addons'),
				"default"  => 0,
			),
			array(
				'id'       =>'sale-color',
				'type'     => 'color',
				'title'    => esc_html__('Sale color', 'themefushion-addons'),
				'default'  => '#f25c05',
                'transparent' => false
			),
			array(
				'id'       =>'discount-color',
				'type'     => 'color',
				'title'    => esc_html__('Discount color', 'themefushion-addons'),
				'default'  => '#66bbf2',
                'transparent' => false
			),
			array(
				'id'       =>'wishlist',
				'type'     => 'switch',
				'title'    => esc_html__('Product wishlist', 'themefushion-addons'),
				"default"  => 0
			),
			array(
				'id'       =>'compare',
				'type'     => 'switch',
				'title'    => esc_html__('Product compare', 'themefushion-addons'),
				"default"  => 0
			),
			array(
				'id'      =>'product-wishlist-page',
				'type'     => 'text',
				'title'    => esc_html__('Wishlist page url', 'themefushion-addons'),
				'required' => array('wishlist','equals',1)
			),
			array(
				'id'      =>'product-compare-page',
				'type'     => 'text',
				'title'    => esc_html__('Compare page url', 'themefushion-addons'),
				'required' => array('compare','equals',1)
			),
			array(
				'id'        =>'product-single-sidebar',
				'type'      => 'select',
				'title'     => esc_html__('Single product sidebar position', 'themefushion-addons'),
				'options'   => array(
					'none'  => esc_html__('None', 'themefushion-addons'),
					'left'  => esc_html__('Left', 'themefushion-addons'),
					'right' => esc_html__('Right', 'themefushion-addons'),
				),
				'default' => 'none',
			),
			array(
				'id'       => 'product-single-post-layout',
				'type'     => 'image_select',
				'title'    => esc_html__('Single product layout', 'themefushion-addons'),
				'width'    => '140',
				'height'   => '140',
				'options'  => array(
					'single-product-thumbnails-down' => array(
						'alt'   => 'Horizonal thumbnails',
						'title' => 'Horizonal thumbnails',
						'img'   => THEME_IMG.'product_post_layout_1.png'
					),
					'single-product-thumbnails-left' => array(
						'alt'   => 'Vertical thumbnails',
						'title' => 'Vertical thumbnails',
						'img'   => THEME_IMG.'product_post_layout_2.png'
					),
				),
				'default' => 'single-product-thumbnails-down'
			),
			array(
				'id'       =>'product-single-social',
				'type'     => 'switch',
				'title'    => esc_html__('Social share', 'themefushion-addons'),
				"default"  => 1
			)
		)
	));

?>
